import Button from "react-bootstrap/Button";

function Doors(){
    return(
        <div>
            <h1>Informacion sobre las puertas</h1>
            <Button variant="dark" href="/indexHouse">Volver</Button>
        </div>
    )
}
export default Doors